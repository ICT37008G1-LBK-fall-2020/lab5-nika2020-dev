//1.1	დაწერეთ კოდი რომელიც აიღებს head ელემენტს
console.log(document.head.children[0]);

//1.2	დაწერეთ კოდი რომელიც აიღებს ul ელემენტს
console.log(document.getElementsByTagName('ul'));

//1.3	დაწერეთ კოდი რომელიც აიღებს მეორე li ელემენტს
console.log(document.getElementsByTagName('li')[1]);



